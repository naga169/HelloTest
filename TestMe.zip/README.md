# Football Comptestions

## API to hit

`https://jsonmock.hackerrank.com/api/football_competitions?year=<year>`

## Expected Outputs when result found

- `Match {name} won by {winner}`
- `Total Matches: {count}`

## Expected Output when NO results found

In case of no results render below div
`<div data-testid="no-result">No Matches Found</div>`